"use client";
import React, { useState } from 'react';
import axios from 'axios';
import FileUpload from './components/FileUpload';
import ColumnSelector from './components/ColumnSelector';
import { CheckCircle, Download, FileText, AlertCircle } from 'lucide-react';

type ProcessingStep = 'upload' | 'select' | 'download' | 'complete';

function App() {
  const [columns, setColumns] = useState([]);
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);
  const [filename, setFilename] = useState('');
  const [message, setMessage] = useState('');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [totalImages, setTotalImages] = useState(0);
  const [currentStep, setCurrentStep] = useState<ProcessingStep>('upload');
  const [isDownloading, setIsDownloading] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [error, setError] = useState('');

  const handleFileUpload = async (file: File) => {
    try {
      setError('');
      const formData = new FormData();
      formData.append('file', file);
      const res = await axios.post('http://127.0.0.1:5000/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
      setColumns(res.data.columns);
      setFilename(res.data.filename);
      setUploadedFileName(file.name);
      setCurrentStep('select');
    } catch (err) {
      setError('Failed to upload file. Please try again.');
      console.error('Upload error:', err);
    }
  };

  const handleDownload = async () => {
    try {
      setError('');
      setIsDownloading(true);
      setCurrentStep('download');
      
      const res = await axios.post('http://127.0.0.1:5000/download-images', {
        filename,
        columns: selectedColumns
      });
      
      setMessage(res.data.message);
      setCurrentStep('complete');
    } catch (err) {
      setError('Failed to download images. Please try again.');
      console.error('Download error:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  const resetProcess = () => {
    setColumns([]);
    setSelectedColumns([]);
    setFilename('');
    setMessage('');
    setDownloadUrl('');
    setTotalImages(0);
    setCurrentStep('upload');
    setUploadedFileName('');
    setError('');
  };

  const handleDirectDownload = () => {
    if (downloadUrl) {
      window.open(downloadUrl, '_blank');
    }
  };

  const getStepStatus = (step: ProcessingStep) => {
    const stepOrder = ['upload', 'select', 'download', 'complete'];
    const currentIndex = stepOrder.indexOf(currentStep);
    const stepIndex = stepOrder.indexOf(step);
    
    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'current';
    return 'pending';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            HubSpot Image Downloader
          </h1>
          <p className="text-lg text-gray-600">
            Professional bulk image downloading tool for your marketing assets
          </p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-8">
            {[
              { key: 'upload', label: 'Upload File', icon: FileText },
              { key: 'select', label: 'Select Columns', icon: CheckCircle },
              { key: 'download', label: 'Download Images', icon: Download },
              { key: 'complete', label: 'Complete', icon: CheckCircle }
            ].map(({ key, label, icon: Icon }, index) => {
              const status = getStepStatus(key as ProcessingStep);
              return (
                <div key={key} className="flex items-center">
                  <div className="flex flex-col items-center">
                    <div className={`
                      w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all duration-300
                      ${status === 'completed' ? 'bg-green-500 border-green-500 text-white' : 
                        status === 'current' ? 'bg-blue-500 border-blue-500 text-white' : 
                        'bg-gray-200 border-gray-300 text-gray-500'}
                    `}>
                      <Icon size={20} />
                    </div>
                    <span className={`mt-2 text-sm font-medium ${
                      status === 'current' ? 'text-blue-600' : 
                      status === 'completed' ? 'text-green-600' : 'text-gray-500'
                    }`}>
                      {label}
                    </span>
                  </div>
                  {index < 3 && (
                    <div className={`w-16 h-0.5 mx-4 ${
                      getStepStatus(['select', 'download', 'complete'][index] as ProcessingStep) === 'completed' ? 
                      'bg-green-500' : 'bg-gray-300'
                    }`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 max-w-2xl mx-auto">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center">
              <AlertCircle className="text-red-500 mr-3" size={20} />
              <span className="text-red-700">{error}</span>
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          {currentStep === 'upload' && (
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <FileUpload onUpload={handleFileUpload} />
            </div>
          )}

          {currentStep === 'select' && (
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <div className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-gray-900">
                    File Uploaded Successfully
                  </h3>
                  <button
                    onClick={resetProcess}
                    className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                  >
                    Upload Different File
                  </button>
                </div>
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center">
                  <CheckCircle className="text-green-500 mr-3" size={20} />
                  <span className="text-green-700">
                    <strong>{uploadedFileName}</strong> processed successfully. 
                    Found {columns.length} columns.
                  </span>
                </div>
              </div>

              <ColumnSelector
                columns={columns}
                selected={selectedColumns}
                onChange={setSelectedColumns}
              />

              {selectedColumns.length > 0 && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <button
                    onClick={handleDownload}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 flex items-center justify-center"
                  >
                    <Download className="mr-2" size={20} />
                    Download Images from {selectedColumns.length} Column{selectedColumns.length !== 1 ? 's' : ''}
                  </button>
                </div>
              )}
            </div>
          )}

          {currentStep === 'download' && (
            <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
              <div className="mb-6">
                <div className="animate-spin w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Downloading Images...
                </h3>
                <p className="text-gray-600">
                  Processing {selectedColumns.length} column{selectedColumns.length !== 1 ? 's' : ''} from {uploadedFileName}
                </p>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-700 text-sm">
                  This may take a few minutes depending on the number of images. 
                  Please don't close this window.
                </p>
              </div>
            </div>
          )}

          {currentStep === 'complete' && (
            <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
              <div className="mb-6">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Download Complete!
                </h3>
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                  <p className="text-green-700 mb-2">{message}</p>
                  <p className="text-green-600 text-sm">
                    Successfully processed {totalImages} images from {selectedColumns.length} column{selectedColumns.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <button
                  onClick={handleDirectDownload}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 flex items-center justify-center mb-3"
                >
                  <Download className="mr-2" size={20} />
                  Download ZIP File ({totalImages} images)
                </button>

                <button
                  onClick={resetProcess}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200"
                >
                  Process Another File
                </button>
              </div>

              <div className="mt-4 text-sm text-gray-500">
                <p>💡 The ZIP file contains images organized by column name</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-500 text-sm">
          <p>© 2025 HubSpot Image Downloader - Professional Marketing Tools</p>
        </div>
      </div>
    </div>
  );
}

export default App;